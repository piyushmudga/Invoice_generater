from django.shortcuts import render
from  . models import producat,seller,buyer
import datetime
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate,login,logout

from app.forms import CreateUserForm
# Create your views here.
@login_required(login_url='login')
def index(request):
    pro = producat.objects.all()
    slr = seller.objects.all()
    return render(request,'index.html',{'products':pro,'seller':slr})


def buy(request,pk):
    print(pk)
    pro = producat.objects.get(pk=pk)

    if request.method == "POST":
        name = request.POST['name']
        address = request.POST['address']
        phone = request.POST['phone']
        quantity = int(request.POST['quantity'])
        
        by = buyer(name=name,address=address,phone=phone)
        by.save()
        amount = float(pro.price)
        pn = pro.name
        dis = pro.dis
        price = amount
        pro_quantity =quantity
        pro_total = amount*quantity         
        slr = seller.objects.all()
        data = {'pname':pn,'pprice':price,'bname':name,'baddress':address,'bphone':phone,'pdis':dis,'pquantity':pro_quantity, 'ptotal':pro_total}
        return render(request, 'pdf.html', {'data': data, 'seller': slr})

    return render(request, 'buy.html')


def pdf(request):
    slr = seller.objects.all()
    return render(request,'pdf.html',{'seller':slr})

def customerregistration(request):
    if request.method=='POST':
        form=CreateUserForm(request.POST)
        if form.is_valid():
            form.save()
    else:
        form=CreateUserForm()
        return render(request,'customerregistration.html',{'form':form})
    
    return render(request,'customerregistration.html')



def ulogin(request):
    if request.method=='POST':
        username=request.POST.get('uname')
        pwd=request.POST.get('pwd')
        # print(username,pwd)
        user=authenticate(username=username,password=pwd)
        if user is not None:
            login(request,user)
            return render(request,'index.html')
        else:
            messages.info(request,'Incorrect username and password')
            return render(request,'home.html')

    return render(request,'login.html')

def userlogout(request):
    logout(request)
    return render(request,'index.html')
